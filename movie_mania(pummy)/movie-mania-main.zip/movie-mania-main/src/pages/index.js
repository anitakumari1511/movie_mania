import Dashboard from "./Dashboard";
import MovieDetail from "./MovieDetail";

export { Dashboard, MovieDetail };
